1. Open the Working directory
2. Edit the GenerateDoc.bat file
3. Change the first three lines
  3.1. ManiaPlanetDrive: set the drive letter of the hard disk containing ManiaPlanet
  3.2. ManiaPlanetDir: set the directory where the ManiaPlanet.exe is
  3.3. DoxygenDir: set the directory where the doxygen.exe is
4. Save the file and quit
5. Double click on GenerateDoc.bat
6. Close the ManiaPlanet window
7. Press enter to close the Windows command prompt
8. Open the index.html file with your internet browser to read the documentation