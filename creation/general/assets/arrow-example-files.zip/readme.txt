this package contains:
- the arrow.blend (blender file)
- arrow-Item.zip (the ready to use Item)
- arrow-work.zip (the data to put into Work/Items/myItems/arrow)